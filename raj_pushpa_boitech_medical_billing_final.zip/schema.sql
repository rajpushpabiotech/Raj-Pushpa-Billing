-- Medical Billing Pro: cloud database starter schema
-- Designed for PostgreSQL/Supabase-style databases.
create table if not exists businesses (
  id uuid primary key,
  name text not null,
  gstin text,
  mobile text,
  email text,
  address text,
  invoice_prefix text default 'INV',
  created_at timestamptz default now()
);

create table if not exists customers (
  id uuid primary key,
  business_id uuid references businesses(id) on delete cascade,
  name text not null,
  mobile text,
  address text,
  created_at timestamptz default now()
);

create table if not exists medicines (
  id uuid primary key,
  business_id uuid references businesses(id) on delete cascade,
  name text not null,
  hsn text,
  barcode text,
  batch text not null,
  expiry date,
  mrp numeric(12,2) default 0,
  purchase_rate numeric(12,2) default 0,
  sale_rate numeric(12,2) default 0,
  gst numeric(5,2) default 0,
  qty numeric(12,3) default 0,
  created_at timestamptz default now()
);

create table if not exists invoices (
  id uuid primary key,
  business_id uuid references businesses(id) on delete cascade,
  customer_id uuid references customers(id),
  invoice_no text not null,
  invoice_date timestamptz default now(),
  subtotal numeric(12,2) default 0,
  tax numeric(12,2) default 0,
  total numeric(12,2) default 0,
  status text default 'posted'
);

create table if not exists invoice_items (
  id uuid primary key,
  invoice_id uuid references invoices(id) on delete cascade,
  medicine_id uuid references medicines(id),
  medicine_name text not null,
  batch text,
  hsn text,
  qty numeric(12,3) not null,
  rate numeric(12,2) not null,
  gst numeric(5,2) default 0,
  taxable numeric(12,2) default 0,
  tax numeric(12,2) default 0,
  total numeric(12,2) default 0
);

create table if not exists stock_movements (
  id uuid primary key,
  business_id uuid references businesses(id) on delete cascade,
  medicine_id uuid references medicines(id),
  movement_type text not null,
  reference_no text,
  qty numeric(12,3) not null,
  created_at timestamptz default now()
);

create index if not exists medicines_barcode_idx on medicines(business_id, barcode);
create index if not exists medicines_expiry_idx on medicines(business_id, expiry);
create index if not exists invoices_date_idx on invoices(business_id, invoice_date);
