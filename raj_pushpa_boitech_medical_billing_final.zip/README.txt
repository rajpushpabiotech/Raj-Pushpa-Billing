MEDICAL BILLING PRO — FINAL PACKAGE

Current package:
- Responsive billing UI for Android and desktop browsers
- Medicine/batch/expiry/stock
- GST/HSN invoice
- Sales returns
- Low-stock/expiry alerts
- Sales history + CSV export
- Business settings
- Local backup/restore

CLOUD-READY DATABASE:
Use schema.sql to create the production database in a PostgreSQL/Supabase-style service.

IMPORTANT:
This package does not pretend to have a live cloud backend. Before real business use,
connect the UI to a hosted database and authentication service, configure security rules,
test backups, and validate GST/accounting requirements with your CA/accountant.

ANDROID:
Serve the app over HTTPS. In Chrome/Edge on Android, use "Install app" / "Add to Home screen".
A Trusted HTTPS origin is required for reliable PWA/service-worker behavior.

BARCODE:
Most USB/Bluetooth barcode scanners behave like keyboards and can enter a barcode into
the barcode field. Camera barcode scanning requires a browser/device API integration.

THERMAL PRINT:
Thermal printers require device/browser-specific integration. The current invoice is
print-friendly; a dedicated 58/80mm print stylesheet can be added after the printer model
is selected.

SECURITY:
Do not store production passwords or sensitive credentials in the frontend. Use authenticated
server/database access and row-level access controls for a multi-user deployment.
